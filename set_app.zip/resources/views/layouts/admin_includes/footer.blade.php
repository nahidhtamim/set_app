<footer class="footer text-center"> Copyright © 2022 SET.com <br>
    <span>Developed By</span> <a href="nahidhtamim.top">NHT</a>
</footer>