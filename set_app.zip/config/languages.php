
<?php
return [
    'en' => 'ENG',
    'gr' => 'GER',
];
