
 <?php $__env->startSection('title'); ?>
 Home | SET - A Premium Laundry Service
 <?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>

<?php if(session('status')): ?>
    <div class="alert alert-success" role="alert">
         <?php echo e(session('status')); ?>

         <a class="close">&times;</a>
    </div>
<?php elseif(session('warning')): ?>
    <div class="alert alert-danger" role="alert">
         <?php echo e(session('warning')); ?>

         <a class="close">&times;</a>
    </div>    
<?php endif; ?>

  <!-- ***** Main Banner Area Start ***** -->
  <section class="section main-banner" id="top" data-section="section1">
    <video autoplay muted playsinline="" id="bg-video">
      <source src="<?php echo e(asset('frontend/assets/images/set.mp4')); ?>" type="video/mp4">
    </video>
    
  

    <div class="video-overlay header-text">
        <div class="container">
          <div class="row">
            <div class="col-lg-12">
              <div class="caption">
            <h6>Hello There</h6>
            <h2><?php echo e(__('messages.welcome')); ?></h2>
            <p><?php echo e(__('messages.sportswear_service')); ?></p>
            <div class="main-button-red">
                <div class="scroll-to-section"><a href="#meetings"><?php echo e(__('messages.get_premium')); ?></a></div>
            </div>
        </div>
            </div>
          </div>
        </div>
    </div>
</section>
<!-- ***** Main Banner Area End ***** -->


<section class="services">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="owl-service-item owl-carousel">
        
          <div class="item">
            <!-- <div class="icon">
              <img src="assets/images/service-icon-01.png" alt="">
            </div> -->
            <div class="down-content">
              <h4><?php echo e(__('messages.sports_equipment')); ?></h4>
              <p><?php echo e(__('messages.sports_equipment_para')); ?></p>
            </div>
          </div>
          <div class="item">
            <!-- <div class="icon">
              <img src="assets/images/service-icon-01.png" alt="">
            </div> -->
            <div class="down-content">
              <h4><?php echo e(__('messages.pickups')); ?></h4>
              <p><?php echo e(__('messages.pickups_para')); ?></p>
            </div>
          </div>
          <div class="item">
            <!-- <div class="icon">
              <img src="assets/images/service-icon-01.png" alt="">
            </div> -->
            <div class="down-content">
              <h4><?php echo e(__('messages.individual')); ?></h4>
              <p><?php echo e(__('messages.individual_para')); ?></p>
            </div>
          </div>
          <div class="item">
            <!-- <div class="icon">
              <img src="assets/images/service-icon-01.png" alt="">
            </div> -->
            <div class="down-content">
              <h4><?php echo e(__('messages.athlete')); ?></h4>
              <p><?php echo e(__('messages.athlete_para')); ?></p>
            </div>
          </div>
          
          <div class="item">
            <!-- <div class="icon">
              <img src="assets/images/service-icon-02.png" alt="">
            </div> -->
            <div class="down-content">
              <h4><?php echo e(__('messages.pickup')); ?></h4>
              <p><?php echo e(__('messages.pickup_para')); ?></p>
            </div>
          </div>
          
          <div class="item">
            <!-- <div class="icon">
              <img src="assets/images/service-icon-03.png" alt="">
            </div> -->
            <div class="down-content">
              <h4><?php echo e(__('messages.flexible')); ?></h4>
              <p><?php echo e(__('messages.flexible_para')); ?></p>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>
</section>

<section class="our-facts">
  <div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="row">
               
                <div class="col-lg-6 about-area">
                    <div class="row">
                        
                        <div class="col-lg-6">
                          <div class="about-area-content">
                              <div class="count"><?php echo e(__('messages.before')); ?></div>
                              <div class="">
                                <?php if(session('applocale') == 'en'): ?>
                                  <img src="<?php echo e(asset('frontend/assets/images/about-slider/E1.png')); ?>"
                                  class="d-block w-100 img-fluid" alt="..." style="border-radius: 5%;">
                                <?php else: ?>
                                  <img src="<?php echo e(asset('frontend/assets/images/about-slider/G1.png')); ?>"
                                  class="d-block w-100 img-fluid" alt="..." style="border-radius: 5%;">
                                <?php endif; ?>
                              </div>
                          </div>
                      </div>
                        <div class="col-lg-6">
                            <div class="about-area-content">
                                <div class="count"><?php echo e(__('messages.after')); ?></div>
                                <div class="">
                                  <?php if(session('applocale') == 'en'): ?>
                                    <img src="<?php echo e(asset('frontend/assets/images/about-slider/E2.png')); ?>"
                                    class="d-block w-100 img-fluid" alt="..." style="border-radius: 5%;">
                                  <?php else: ?>
                                    <img src="<?php echo e(asset('frontend/assets/images/about-slider/G2.png')); ?>"
                                    class="d-block w-100 img-fluid" alt="..." style="border-radius: 5%;">
                                  <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-12 text-center">
                  <a href="<?php echo e(url('/about')); ?>" class="text-light">
                  <h2><?php echo e(__('messages.know_us')); ?>

                    <i class="fa fa-long-arrow-right" aria-hidden="true"></i>
                  </h2>
                </a> 
              </div>
            </div>
        </div>
    </div>
  </div>
</section>

<section class="upcoming-meetings" id="meetings">
  <div class="container">
    <div class="row">
      
      
      <div class="col-lg-12">
        <div class="section-heading">
          <h2><?php echo e(__('messages.offerings')); ?></h2>
        </div>
      </div>
      <div class="col-lg-12">
        <div class="row">
          <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-6">
            <div class="meeting-item">
              <div class="thumb">
                <div class="price">
                  <span><?php echo e($service->service_price); ?>€</span>
                </div>
                <a href="<?php echo e(url('/service/'.$service->id)); ?>"><img src="/uploads/services/<?php echo e($service->service_image); ?>" alt="<?php echo e($service->service_name); ?>"></a>
              </div>
              <div class="down-content">
                <div class="date">
                  <?php if($service->id == 1): ?>
                  <h6><i class="fa fa-star" aria-hidden="true"></i></h6>
                  <?php elseif($service->id == 2): ?>
                  <h6><i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i></h6>
                  <?php elseif($service->id == 3): ?>
                  <h6><i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i>
                  <i class="fa fa-star" aria-hidden="true"></i></h6>
                  <?php endif; ?>
                </div>
                <?php if(session('applocale') == 'en'): ?>
                  <a href="<?php echo e(url('/service/'.$service->id)); ?>"><h4><?php echo e($service->service_name); ?></h4></a>
                  <p><?php echo e($service->short_desc); ?></p>
                <?php else: ?>
                  <a href="<?php echo e(url('/service/'.$service->id)); ?>"><h4><?php echo e($service->service_name_ger); ?></h4></a>
                  <p><?php echo e($service->short_desc_ger); ?></p>
                <?php endif; ?>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
          <div class="col-lg-6">
            <div class="meeting-item">
              <div class="thumb">
                <div class="price">
                  <span>Contact</span>
                </div>
                <a href="#contact"><img src="<?php echo e(asset('frontend/assets/images/meeting-04.jpg')); ?>" alt="Student Training"></a>
              </div>
              <div class="down-content">
                <div class="date">
                  <h6><i class="fa fa-star-o" aria-hidden="true"></i>
                  </h6>
                </div>
                <a href="#contact"><h4>Set Custom</h4></a>
                <p>Morbi in libero blandit lectus cursus ullamcorper.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\set_app\resources\views/frontend/index.blade.php ENDPATH**/ ?>