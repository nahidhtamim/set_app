
<?php $__env->startSection('title'); ?>
Order | SET - A Premium Laundry Service
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>



<section class="meetings-page" id="meetings">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="order-form" id="order-form">
                    <div class="align-self-center">
                        <div class="row">
                            <div id="order-form">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <?php if($hasOrder == true): ?>
                                        <?php if(session('status')): ?>
                                        <div class="alert alert-success" role="alert">
                                            <?php echo e(session('status')); ?>

                                            <a class="close">&times;</a>
                                        </div>
                                        <?php elseif(session('warning')): ?>
                                        <div class="alert alert-danger" role="alert">
                                            <?php echo e(session('warning')); ?>

                                            <a class="close">&times;</a>
                                        </div>
                                        <?php endif; ?>

                                        <div class="col-lg-12 text-center">
                                            <h1>Order Info</h1>
                                            <hr>
                                            
                                            <div class="card">
                                                <div class="card-header">
                                                    <h5>Order Details</h5>
                                                </div>
                                                <div class="card-body">
                                                    <p><b>Name:</b> <?php echo e($order->u_name); ?></p>
                                                    <p><b>DOB:</b> <?php echo e($order->dob); ?></p>
                                                    <p><b>Gender:</b> <?php echo e($order->gender); ?></p>
                                                    <p><b>Sport:</b> <?php echo e($order->sport_name); ?></p>
                                                    <p><b>Service Price:</b> <?php echo e($order->s_price); ?>€</p>

                                                    <table class="table text-center table-bordered table-striped">
                                                        <thead>
                                                            <tr>
                                                                <th class="border-top-0">Service Details</th>
                                                                <th class="border-top-0">Locker Details</th>
                                                                <th class="border-top-0">Shipping Details</th>
                                                                <th class="border-top-0">Billing Details</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td>
                                                                    <b>Service:</b> <?php echo e($order->s_name); ?> <br>
                                                                    <b>Place Service:</b> <?php echo e($order->ps_name); ?> <br>
                                                                    <b>Service Code:</b> <?php echo e($order->ps_code); ?>

                                                                </td>
                                                                <td>
                                                                    <b>Locker:</b> <?php echo e($order->l_name); ?> <br>
                                                                    <b>Place Locker:</b> <?php echo e($order->pl_name); ?> <br>
                                                                    <b>Locker Code:</b> <?php echo e($order->pl_code); ?>

                                                                </td>
                                                                <td>
                                                                    <b>Name:</b> <?php echo e($order->shipping_name); ?> <br>
                                                                    <b>Email:</b> <?php echo e($order->shipping_email); ?> <br>
                                                                    <b>Phone:</b> <?php echo e($order->shipping_phone); ?> <br>
                                                                    <b>Address:</b> <?php echo e($order->shipping_address); ?>

                                                                </td>
                                                                <td>
                                                                    <b>Name:</b> <?php echo e($order->billing_name); ?> <br>
                                                                    <b>Email:</b> <?php echo e($order->billing_email); ?> <br>
                                                                    <b>Phone:</b> <?php echo e($order->billing_phone); ?> <br>
                                                                    <b>Address:</b> <?php echo e($order->billing_address); ?>

                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div class="card-footer">
                                                    <div class="row">
                                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                                            <p>
                                                                <b>Order Status:</b>
                                                                <?php echo e($order->order_status_name); ?>

                                                            </p>
                                                        </div>
                                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                                            <b>Action:</b>
                                                            <div class="btn-group" role="group" aria-label="Buttons">
                                                                <?php if($order->order_status < 9): ?>
                                                                <a href="<?php echo e(url('/request-closing/'.$order->id)); ?>"
                                                                    class="btn btn-danger btn-sm" onclick="return confirm('Are you sure to cancel the service?')"
                                                                    data-bs-toggle="tooltip" data-bs-placement="top"
                                                                    title="Close The Order">
                                                                    <i class="fa fa-times" aria-hidden="true"></i>
                                                                </a>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                            
                                        </div>

                                        <div class="col-lg-12 pt-5">
                                            <div class="card">
                                                <div class="card-header">
                                                    <h5 class="text-center">Clothing SET Details</h5>
                                                </div>
                                                <div class="card-body text-center">
                                                    <?php $__currentLoopData = $cloths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cloth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <p>
                                                        <button class="btn btn-primary w-50 my-2" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($cloth->hexa_code); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($cloth->hexa_code); ?>">
                                                            Set: <?php echo e($cloth->set_id); ?> <> 
                                                            Status: <?php if($cloth->wash_program_number == '0'): ?>
                                                            New Entry
                                                            <?php else: ?>
                                                            <?php echo e($cloth->service_cycle_location_inf->location); ?>

                                                            <?php endif; ?>
                                                        </button>
                                                    </p>
                                                    <div class="collapse" id="collapse<?php echo e($cloth->hexa_code); ?>">
                                                        <div class="card card-body">
                                                            
                                                            <table class="table text-nowrap table-bordered table-striped">
                                                                <thead>
                                                                    <tr>
                                                                        <th class="border-top-0">#</th>
                                                                        <th class="border-top-0">Washing Program</th>
                                                                        <th class="border-top-0">Color Group</th>
                                                                        <th class="border-top-0">Cloth Type</th>
                                                                        <th class="border-top-0">Fabric</th>
                                                                        <th class="border-top-0">Sportswear Type</th>
                                                                        <th class="border-top-0">Description</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <?php $__currentLoopData = $clothing_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laundry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($laundry->set_id == $cloth->set_id): ?>
                                                                    <tr>
                                                                        <td><?php echo e($loop->iteration); ?></td>
                                                                        <td><?php echo e($laundry->washing_program_inf->name); ?></td>
                                                                        <td><?php echo e($laundry->cloth_group_inf->name); ?></td>
                                                                        <td><?php echo e($laundry->cloth_type_inf->name); ?></td>
                                                                        <td><?php echo e($laundry->fabric_inf->name); ?></td>
                                                                        <td><?php echo e($laundry->sportswear_inf->name); ?></td>
                                                                        <td><?php echo $laundry->laundry_description; ?></td>
                                                                    </tr>
                                                                    <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </tbody>
                                                            </table>
                                                           
                                                        </div>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                    <div class="col-lg-12 text-center">
                                        <h1 class="text-dark">This service is currently unavailable for you. To use this function please place an order</h1>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <br>
    <br>
    <br>
    <br>
    <br>
</section>


<style>
    .page-item.active .page-link {
        z-index: 3;
        color: #fff;
        background-color: #1B2325;
        border-color: #1B2325;
    }

    .dataTables_length label {
        padding-bottom: 10px;
        text-align: center;
    }

    .dataTables_wrapper .dataTables_length select {
        border: 1px solid #aaa;
        border-radius: 20px;
        padding: 5px;
        background-color: transparent;
        padding: 4px;
    }

    .order-form #order-form select {
        width: 40%;
        height: 30px;
        border-radius: 20px;
        background-color: #f7f7f7;
        outline: none;
        border: 1px solid #aaa;
        box-shadow: none;
        font-size: 13px;
        font-weight: 500;
        color: #252525;
        padding: 0px 15px;
        margin-bottom: 0px;
    }

    .dataTables_filter label {
        text-align: center;
    }

    .order-form #order-form input {
        width: 80%;
        height: 30px;
        border-radius: 20px;
        background-color: #f7f7f7;
        outline: none;
        border: 1px solid #aaa;
        box-shadow: none;
        font-size: 13px;
        font-weight: 500;
        color: #252525;
        padding: 0px 15px;
        margin-bottom: 10px;

    }

</style>

<script>
    $(document).ready(function () {

        $('.onClosing').on('click', function (event) {
            event.preventDefault();
            const url = $(this).attr('href');
            swal({
                title: 'Are you sure?',
                text: "7 days prior notification is must to completely close the order.",
                icon: "warning",
                // buttons: ["Cancel", "Yes!"],
                buttons: true,
                dangerMode: true,
            }).then(function (value) {
                if (value) {
                    swal("Order has been set for closing.", {
                        icon: "success",
                    });
                    window.location.href = url;
                }
            });
        });

    });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\set_app\resources\views/frontend/order.blade.php ENDPATH**/ ?>