
 <?php $__env->startSection('title'); ?>
 Edit Laundry - SET Admin Panel
 <?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>
            
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb bg-white">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Laundry</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <div class="d-md-flex">
                            <ol class="breadcrumb ms-auto">
                                <li><a href="<?php echo e(url('/edit-laundry/'.$laundry->id)); ?>" class="fw-normal">Edit Laundry</a></li>
                            </ol>
                        </div>
                    </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Three charts -->
                <!-- ============================================================== -->
                <div class="col-lg-12 col-xlg-12 col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <form class="form-horizontal form-material" method="POST" action="<?php echo e(url('/update-laundry/'.$laundry->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group mb-4">
                                    <label class="col-md-12 p-0"><b>Washing Program <span class="text-danger">*</span></b></label>
                                    <select id="inputState" class="form-select shadow-none p-0 border-0 " name="washing_program" required>
                                        <option value="<?php echo e($laundry->washing_program); ?>" selected><?php echo e($laundry->washing_program_inf->name); ?></option>
                                        <option>============</option>
                                        <?php $__currentLoopData = $washing_programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $washing_program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($washing_program->id); ?>"><?php echo e($washing_program->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group mb-4">
                                    <label class="col-md-12 p-0"><b>Cloth Group <span class="text-danger">*</span></b></label>
                                    <select id="inputState" class="form-select shadow-none p-0 border-0 " name="cloth_group" required>
                                        <option value="<?php echo e($laundry->cloth_group); ?>" selected><?php echo e($laundry->cloth_group_inf->name); ?></option>
                                        <option>============</option>
                                        <?php $__currentLoopData = $cloth_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cloth_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cloth_group->id); ?>"><?php echo e($cloth_group->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group mb-4">
                                    <label class="col-md-12 p-0"><b>Cloth Type <span class="text-danger">*</span></b></label>
                                    <select id="inputState" class="form-select shadow-none p-0 border-0 " name="cloth_type" required>
                                        <option value="<?php echo e($laundry->cloth_type); ?>" selected><?php echo e($laundry->cloth_type_inf->name); ?></option>
                                        <option>============</option>
                                        <?php $__currentLoopData = $cloth_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cloth_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cloth_type->id); ?>"><?php echo e($cloth_type->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group mb-4">
                                    <label class="col-md-12 p-0"><b>Fabric <span class="text-danger">*</span></b></label>
                                    <select id="inputState" class="form-select shadow-none p-0 border-0 " name="fabric" required>
                                        <option value="<?php echo e($laundry->fabric); ?>" selected><?php echo e($laundry->fabric_inf->name); ?></option>
                                        <option>============</option>
                                        <?php $__currentLoopData = $fabrics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fabric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($fabric->id); ?>"><?php echo e($fabric->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group mb-4">
                                    <label class="col-md-12 p-0"><b>Sportswear <span class="text-danger">*</span></b></label>
                                    <select id="inputState" class="form-select shadow-none p-0 border-0 " name="sportswear_type" required>
                                        <option value="<?php echo e($laundry->sportswear_type); ?>" selected><?php echo e($laundry->sportswear_inf->name); ?></option>
                                        <option>============</option>
                                        <?php $__currentLoopData = $sportswears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sportswear): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($sportswear->id); ?>"><?php echo e($sportswear->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group mb-4">
                                    <label class="col-md-12 p-0"><b>Laundry Description <span class="text-danger">*</span></b></label>
                                    <div class="col-md-12 border-bottom p-0">
                                        <textarea rows="5" class="form-control p-0 border-0" name="laundry_description" required>
                                            SET Laundry Description
                                        </textarea>
                                    </div>
                                </div>
                                <div class="form-group mb-4">
                                    <div class="col-sm-12">
                                        <button class="btn btn-success">Update</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            
          
<?php $__env->stopSection(); ?>
        
        
 
        

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\set_app\resources\views/admin/laundry/edit-laundry.blade.php ENDPATH**/ ?>