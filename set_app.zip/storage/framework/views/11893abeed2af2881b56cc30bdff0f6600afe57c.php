
 <?php $__env->startSection('title'); ?>
 About | SET - A Premium Laundry Service
 <?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>

<?php if(session('status')): ?>
    <div class="alert alert-success" role="alert">
         <?php echo e(session('status')); ?>

    </div>
<?php elseif(session('warning')): ?>
    <div class="alert alert-danger" role="alert">
         <?php echo e(session('warning')); ?>

    </div>    
<?php endif; ?>

<section class="our-facts">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2>Get To Know Us Better</h2>
          </div>
          <div class="col-lg-6 about-area">
            <div class="row">
              <div class="col-lg-12">
                <div class="about-area-content">
                  <div class="count-digit">About-Us</div>
                  <div class="count-title">Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugit tenetur tempora illo consequuntur aperiam esse impedit distinctio eius incidunt ratione unde alias, a vitae aspernatur? Exercitationem id beatae corrupti vel!
                    <br>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugit tenetur tempora illo consequuntur 
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div> 
      <div class="col-lg-12 align-self-center">
        <div class="video text-center">
          <a href="https://www.youtube.com/watch?v=HndV87XpkWg" target="_blank"><img src="<?php echo e(asset('frontend/assets/images/play-icon.png')); ?>" alt=""></a>
        </div>
      </div>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\set_app\resources\views/frontend/about.blade.php ENDPATH**/ ?>