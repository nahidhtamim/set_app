
 <?php $__env->startSection('title'); ?>
 Service | SET - A Premium Laundry Service
 <?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>

<?php if(session('status')): ?>
    <div class="alert alert-success" role="alert">
         <?php echo e(session('status')); ?>

         <a class="close">&times;</a>
    </div>
<?php elseif(session('warning')): ?>
    <div class="alert alert-danger" role="alert">
         <?php echo e(session('warning')); ?>

         <a class="close">&times;</a>
    </div>    
<?php endif; ?>

<section class="heading-page header-text" id="top">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <h6>Service</h6>
          <?php if(session('applocale') == 'en'): ?>
          <h2><?php echo e($service->service_name); ?></h2>
          <?php else: ?>
          <h2><?php echo e($service->service_name_ger); ?></h2>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </section>

  <section class="meetings-page" id="meetings">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="row">
            <div class="col-lg-12">
              <div class="meeting-single-item">
                <div class="thumb">
                  <div class="price">
                    <span><?php echo e($service->service_price); ?>.00€</span>
                  </div>
                  
                  <img src="/uploads/services/<?php echo e($service->service_image); ?>" alt="<?php echo e($service->service_name); ?>">
                </div>
                <div class="down-content">
                  <?php if(session('applocale') == 'en'): ?>
                  <h4><?php echo e($service->service_name); ?></h4>
                  <p><?php echo e($service->service_price); ?>.00€</p>
                  <br>
                  <p><?php echo e($service->short_desc); ?></p>
                  <hr>
                  
                  <p class="">
                    <?php echo $service->long_desc; ?>

                  </p>
                  <br>
                 <?php else: ?>
                 <h4><?php echo e($service->service_name_ger); ?></h4>
                  <p><?php echo e($service->service_price); ?>.00€</p>
                  <br>
                  <p><?php echo e($service->short_desc_ger); ?></p>
                  <hr>
                  
                  <p class="">
                    <?php echo $service->long_desc_ger; ?>

                  </p>
                  <br>
                 <?php endif; ?>
                  <?php if(Auth::user()): ?>
                  <div class="main-button-red">
                    <a href="<?php echo e(url('/order-form')); ?>">Order</a>
                  </div>
                  <?php else: ?>
                  <div class="alert alert-warning text-center">Please login or register to order this service!!!</div>
                  <?php endif; ?>
                </div>
              </div>
            </div>
            
          </div>
        </div>
      </div>
    </div>
    <br>
    <br>
    <br>
    <br>
    <br>
  </section>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\github\set_app\resources\views/frontend/service.blade.php ENDPATH**/ ?>