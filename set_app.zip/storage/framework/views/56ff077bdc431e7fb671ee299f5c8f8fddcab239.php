<section class="contact-us" id="contact">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 align-self-center">
                <div class="row">
                    <div class="col-lg-12">

                        <?php if(Session::has('message_sent')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(Session::get('message_sent')); ?>

                            <a href="" class="close">&times;</a>
                        </div>
                        <?php endif; ?>

                        <script src="https://www.google.com/recaptcha/api.js" async defer></script>

                        <form class="contact-form row" method="post" action="<?php echo e(route('contact.send')); ?>" role="form">
                            <?php echo csrf_field(); ?>
                            <div class="col-lg-6 mb-4">
                                <div class="form-floating">
                                    <input type="text"
                                        class="form-control light-300 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="floatingname" name="name" placeholder="Name" required="">
                                    <label for="floatingname light-300">Name <span class="text-danger">*</span></label>
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>
                            <!-- End Input Name -->

                            <div class="col-lg-6 mb-4">
                                <div class="form-floating">
                                    <input type="email"
                                        class="form-control light-300 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="floatingemail" name="email" placeholder="Email" required="">
                                    <label for="floatingemail light-300">Email <span
                                            class="text-danger">*</span></label>
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>
                            <!-- End Input Email -->

                            <div class="col-lg-6 mb-4">
                                <div class="form-floating">
                                    <input type="text"
                                        class="form-control light-300 <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="floatingphone" name="phone" placeholder="Phone">
                                    <label for="floatingphone light-300">Phone <span
                                            class="text-danger">*</span></label>
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>
                            <!-- End Input Phone -->

                            <div class="col-lg-6 mb-4">
                                <div class="form-floating">
                                    <input type="text"
                                        class="form-control light-300 <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="floatingcompany" name="address" placeholder="Address">
                                    <label for="floatingcompany light-300">Address <span
                                            class="text-danger">*</span></label>
                                </div>
                            </div>
                            <!-- End Input Company Name -->

                            <div class="col-12 mb-4">
                                <div class="form-floating">
                                    <textarea class="form-control light-300 <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        rows="8" placeholder="Message" id="floatingtextarea" name="content"></textarea>
                                    <label for="floatingtextarea light-300">Message <span
                                            class="text-danger">*</span></label>
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>
                            <!-- End Textarea Message -->

                            <div class="col-md-8 col-12 mb-4">
                                <div class="form-floating" style="width: 100%">
                                    <?php echo NoCaptcha::renderJs(); ?>


                                    <?php echo NoCaptcha::display(); ?>

                                    <span class="text-danger">
                                        <?php $__errorArgs = ['g-recaptcha-response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="alert alert-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="col-md-4 col-12 m-auto text-end">
                                <button type="submit"
                                    class="btn btn-dark rounded-pill px-md-5 px-4 py-2 radius-0 text-light light-300">Send
                                    Message</button>
                            </div>

                        </form>
                        <br>
                        <br>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="right-info">
                    <ul>
                        <li>
                            <h6><?php echo e(__('messages.phone')); ?></h6>
                            <span>010-020-0340</span>
                        </li>
                        <li>
                            <h6><?php echo e(__('messages.email')); ?></h6>
                            <span><a href="mailto:info@de-set.com" style="text-decoration: none; color: white">
                                    info@de-set.com</a></span>
                        </li>
                        <li>
                            <h6><?php echo e(__('messages.address')); ?></h6>
                            <span>Stuttgart, Germany</span>
                        </li>
                        <li>
                            <h6><?php echo e(__('messages.url')); ?></h6>
                            <span>www.de-set.com</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="footer">
        <p class="text-light">Copyright © 2022 DE-SET.com. All Rights Reserved</p>
        <br>
        <ul>
            <li> <a href="">FAQ</a> </li>
            <li> <p>|</p> </li>
            <li> <a href="">Terms</a> </li>
        </ul>
    </div>
</section>

<script>
  var onloadCallback = function(){
      alert("grecaptcha is ready!");
  }
</script>
<style>
  #rc-anchor-normal {
      height: 74px;
      width: 100% !important;
  }
</style><?php /**PATH C:\xampp\htdocs\set_app\resources\views/layouts/frontend_includes/footer.blade.php ENDPATH**/ ?>