
<?php $__env->startSection('title'); ?>
Order Form | SET - A Premium Laundry Service
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>



<section class="meetings-page" id="meetings">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="order-form" id="order-form">
                    <div class="align-self-center">
                        <div class="row">
                            <form id="order-form" action="<?php echo e(url('/save-order')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div id="info text-center">
                                        <p></p>
                                    </div>

                                    <?php if(session('status')): ?>
                                        <div class="alert alert-success" role="alert">
                                            <?php echo e(session('status')); ?>

                                        </div>
                                    <?php elseif(session('warning')): ?>
                                        <div class="alert alert-danger" role="alert">
                                            <?php echo e(session('warning')); ?>

                                        </div>    
                                    <?php endif; ?>
                                    
                                    <div class="col-lg-12">
                                        <h2>Shipping Details</h2>
                                    </div>
                                    
                                    <div class="col-lg-3 text-center">
                                        <fieldset>
                                            <select name="sport_id" id="sport_id">
                                                <option selected>Select A Sports</option>
                                                <?php $__currentLoopData = $sports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($sport->id); ?>"><?php echo e($sport->sport_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </fieldset>
                                    </div>
                                    <div class="col-lg-3 text-center">
                                        <fieldset>
                                            <select name="place_id" id="place_id">
                                                <option selected>Select A Place</option>
                                                <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($place->id); ?>"><?php echo e($place->place_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </fieldset>
                                    </div>
                                    <div class="col-lg-3 text-center">
                                        <fieldset>
                                            <select name="service_id" id="service_id">
                                                <option selected>Select A Package</option>
                                                
                                            </select>
                                        </fieldset>
                                    </div>
                                    <div class="col-lg-3 text-center">
                                        <fieldset>
                                            <select name="locker_id" id="locker_id">
                                                <option selected>Select A Locker</option>
                                                
                                            </select>
                                        </fieldset>
                                    </div>
                                    <div class="col-lg-6">
                                        <fieldset>
                                            <input name="shipping_name" type="text" id="shipping_name" placeholder="Full Name*"
                                                required="">
                                        </fieldset>
                                    </div>
                                    <div class="col-lg-6">
                                        <fieldset>
                                            <input name="shipping_address" type="text" id="shipping_address" placeholder="Address*"
                                                required="">
                                        </fieldset>
                                    </div>
                                    <div class="col-lg-6">
                                        <fieldset>
                                            <input name="shipping_phone" type="tel" id="shipping_phone" placeholder="Phone No.*"
                                                required="">
                                        </fieldset>
                                    </div>
                                    <div class="col-lg-6">
                                        <fieldset>
                                            <input name="shipping_email" type="text" id="shipping_email" pattern="[^ @]*@[^ @]*"
                                                placeholder="Email Address*" required="">
                                        </fieldset>
                                    </div>
                                    <br>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <h2>Billing Details</h2>
                                    </div>
                                    <div class="col-lg-6">
                                        <fieldset>
                                            <input name="billing_name" type="text" id="billing_name" placeholder="Full Name*"
                                                required="">
                                        </fieldset>
                                    </div>
                                    <div class="col-lg-6">
                                        <fieldset>
                                            <input name="billing_address" type="text" id="billing_address" placeholder="Address*"
                                                required="">
                                        </fieldset>
                                    </div>
                                    <div class="col-lg-6">
                                        <fieldset>
                                            <input name="billing_phone" type="tel" id="billing_phone" placeholder="Phone No.*"
                                                required="">
                                        </fieldset>
                                    </div>
                                    <div class="col-lg-6">
                                        <fieldset>
                                            <input name="billing_email" type="text" id="billing_email" pattern="[^ @]*@[^ @]*"
                                                placeholder="Email Address*" required="">
                                        </fieldset>
                                    </div>
                                    <div class="col-lg-12">
                                        <fieldset>
                                            <textarea name="message" type="text" class="form-control" id="message"
                                                placeholder="Any Notes" required=""></textarea>
                                        </fieldset>
                                    </div>
                                    <div class="col-lg-12">
                                        <fieldset>
                                            <button type="submit" id="form-submit" class="button">Submit</button>
                                        </fieldset>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
    <br>
    <br>
    <br>
    <br>
    <br>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\set_app\resources\views/frontend/order-form.blade.php ENDPATH**/ ?>