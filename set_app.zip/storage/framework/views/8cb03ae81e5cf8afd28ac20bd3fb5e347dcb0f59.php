
 <?php $__env->startSection('title'); ?>
 Place Services - SET Admin Panel
 <?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>
            
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb bg-white">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Place Services</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <div class="d-md-flex">
                            <ol class="breadcrumb ms-auto">
                                <li><a href="<?php echo e(url('/place-services')); ?>" class="fw-normal">Place Services</a></li>
                            </ol>
                            <a href="<?php echo e(url('/add-place-service')); ?>"
                                class="btn btn-success pull-right ms-3 hidden-xs hidden-sm waves-effect waves-light text-white">Add Place Service
                                </a>
                        </div>
                    </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Three charts -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box">
                            <h3 class="box-title">Place Services Table</h3>

                            <?php if(session('status')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php elseif(session('warning')): ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo e(session('warning')); ?>

                            </div>
                            <?php endif; ?>

                            <div class="table-responsive">
                                <table class="table text-nowrap table-bordered table-striped" id="table">
                                    <thead>
                                        <tr>
                                            <th class="border-top-0">#</th>
                                            <th class="border-top-0">Place</th>
                                            <th class="border-top-0">Service</th>
                                            <th class="border-top-0">Name</th>
                                            <th class="border-top-0">Price</th>
                                            <th class="border-top-0">Code</th>
                                            <th class="border-top-0">Status</th>
                                            <th class="border-top-0">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $placeServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $placeservice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($placeservice->place_info->place_name); ?></td>
                                            <td><?php echo e($placeservice->service_info->service_name); ?></td>
                                            <td><?php echo e($placeservice->name); ?></td>
                                            <td><?php echo e($placeservice->service_info->service_price); ?>.00</td>
                                            <td><?php echo e($placeservice->code); ?></td>
                                            <td>
                                                <?php if($placeservice->status == 1): ?>
                                                Active
                                                <a href="<?php echo e(url('place-service-deactive/'.$placeservice->id)); ?>" class="btn btn-warning btn-sm" data-bs-toggle="tooltip" data-bs-placement="top" title="Deactive The Place Service">
                                                    <i class="fa fa-times" aria-hidden="true"></i>
                                                </a>
                                                <?php elseif($placeservice->status == 0): ?>
                                                Deactive
                                                <a href="<?php echo e(url('place-service-active/'.$placeservice->id)); ?>" class="btn btn-success btn-sm" data-bs-toggle="tooltip" data-bs-placement="top" title="Active The Place Service">
                                                    <i class="fa fa-check" aria-hidden="true"></i>
                                                </a>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(url('/edit-place-service/'.$placeservice->id)); ?>"
                                                class="btn btn-info text-white">Edit
                                                </a>
                                                <a href="<?php echo e(url('/delete-place-service/'.$placeservice->id)); ?>"
                                                class="btn btn-danger text-white" onclick="return confirm('Are you sure to delete?')">Delete
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            
<?php $__env->stopSection(); ?>
        
        
 
        

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\set_app\resources\views/admin/placeService/index.blade.php ENDPATH**/ ?>