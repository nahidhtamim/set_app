<aside class="left-sidebar" data-sidebarbg="skin6">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav">
                <!-- User Profile-->
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(url('/dashboard')); ?>"
                        aria-expanded="false">
                        <i class="far fa-clock" aria-hidden="true"></i>
                        <span class="hide-menu">Dashboard</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(url('/notifications')); ?>"
                        aria-expanded="false">
                        <i class="far fa-bell" aria-hidden="true"></i>
                        <span class="hide-menu">Notifications</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(url('/sports')); ?>"
                        aria-expanded="false" data-toggle="tooltip" data-placement="right" title="Sports">
                        <i class="fa fa-futbol" aria-hidden="true"></i>
                        <span class="hide-menu">Sports</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(url('/places')); ?>"
                        aria-expanded="false" data-toggle="tooltip" data-placement="right" title="Places">
                        <i class="fa fa-map-marker" aria-hidden="true"></i>
                        <span class="hide-menu">Places</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(url('/services')); ?>"
                        aria-expanded="false" data-toggle="tooltip" data-placement="right" title="Services">
                        <i class="fa fa-tasks" aria-hidden="true"></i>
                        <span class="hide-menu">Services</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(url('/place-services')); ?>"
                        aria-expanded="false" data-toggle="tooltip" data-placement="right" title="Place Services">
                        <i class="fa fa-map-marker" aria-hidden="true"></i>
                        <i class="fa fa-tasks" aria-hidden="true"></i>
                        <span class="hide-menu">Place Services</span>
                    </a>
                </li>
                
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(url('/lockers')); ?>"
                        aria-expanded="false" data-toggle="tooltip" data-placement="right" title="Lockers">
                        <i class="fa fa-archive" aria-hidden="true"></i>
                        <span class="hide-menu">Lockers</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(url('/place-lockers')); ?>"
                        aria-expanded="false" data-toggle="tooltip" data-placement="right" title="Place Lockers">
                        <i class="fa fa-map-marker" aria-hidden="true"></i>
                        <i class="fa fa-archive" aria-hidden="true"></i>
                        <span class="hide-menu">Place Lockers</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(url('/orders')); ?>"
                        aria-expanded="false" data-toggle="tooltip" data-placement="right" title="Orders">
                        <i class="fa fa-list-alt" aria-hidden="true"></i>
                        <span class="hide-menu">Orders</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(url('/users')); ?>"
                        aria-expanded="false" data-toggle="tooltip" data-placement="right" title="Users">
                        <i class="fa fa-user" aria-hidden="true"></i>
                        <span class="hide-menu">Users</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(route('logout')); ?>"
                        aria-expanded="false" data-toggle="tooltip" data-placement="right" title="Logout"
                        onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();">
                        <i class="fa fa-times" aria-hidden="true"></i>
                        <span class="hide-menu">Logout</span>
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>
                
                
            </ul>

        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</aside><?php /**PATH D:\xampp\htdocs\github\set_app\resources\views/layouts/admin_includes/sidebar.blade.php ENDPATH**/ ?>