
 <?php $__env->startSection('title'); ?>
 Order Payments - SET Admin Panel
 <?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>
            
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb bg-white">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Order Payments</h4>
                    </div>
                    
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Three charts -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box">
                            <h3 class="box-title">Order Payments Table</h3>

                            <?php if(session('status')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php elseif(session('warning')): ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo e(session('warning')); ?>

                            </div>
                            <?php endif; ?>

                            <div class="table-responsive">
                                <table class="table text-nowrap table-bordered table-striped" id="table">
                                    <thead>
                                        <tr>
                                            <th class="border-top-0">#</th>
                                            <th class="border-top-0">Customer Name</th>
                                            <th class="border-top-0">Order No.</th>
                                            <th class="border-top-0">Payment Month</th>
                                            <th class="border-top-0">Payment Year</th>
                                            <th class="border-top-0">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $ops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($op->customer_inf->name); ?></td>
                                            <td><?php echo e($op->order_id); ?></td>
                                            <td>
                                                <?php if($op->month == '1' ): ?>
                                                January
                                                <?php elseif($op->month == '2' ): ?>
                                                February
                                                <?php elseif($op->month == '3' ): ?>
                                                March
                                                <?php elseif($op->month == '4' ): ?>
                                                April
                                                <?php elseif($op->month == '5' ): ?>
                                                May
                                                <?php elseif($op->month == '6' ): ?>
                                                June
                                                <?php elseif($op->month == '7' ): ?>
                                                July
                                                <?php elseif($op->month == '8' ): ?>
                                                August
                                                <?php elseif($op->month == '9' ): ?>
                                                September
                                                <?php elseif($op->month == '10' ): ?>
                                                October
                                                <?php elseif($op->month == '11' ): ?>
                                                November
                                                <?php else: ?>
                                                December
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($op->year); ?></td>
                                            <td>
                                                
                                                <a href="<?php echo e(url('payment-details/'.$op->id)); ?>"
                                                    class="btn btn-info text-white" data-bs-toggle="tooltip" data-bs-placement="top" title="View Invoice">
                                                    <i class="fa fa-file-pdf" aria-hidden="true"></i>
                                                </a>
                                                <a href="<?php echo e(url('delete-payment/'.$op->id)); ?>"
                                                class="btn btn-danger text-white" onclick="return confirm('Are you sure to delete?')">Delete
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            
<?php $__env->stopSection(); ?>
        
        
 
        

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\set_app\resources\views/admin/orders/order-payments.blade.php ENDPATH**/ ?>