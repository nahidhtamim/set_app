
 <?php $__env->startSection('title'); ?>
 Services - SET Admin Panel
 <?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>
            
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb bg-white">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Services</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <div class="d-md-flex">
                            <ol class="breadcrumb ms-auto">
                                <li><a href="<?php echo e(url('/services')); ?>" class="fw-normal">Services</a></li>
                            </ol>
                            <a href="<?php echo e(url('/add-service')); ?>"
                                class="btn btn-success  d-none d-md-block pull-right ms-3 hidden-xs hidden-sm waves-effect waves-light text-white">Add Service
                                </a>
                        </div>
                    </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Three charts -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box">
                            <h3 class="box-title">Services Table</h3>

                            <?php if(session('status')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php elseif(session('warning')): ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo e(session('warning')); ?>

                            </div>
                            <?php endif; ?>

                            <div class="table-responsive">
                                <table class="table text-nowrap table-bordered table-striped" id="table">
                                    <thead>
                                        <tr>
                                            <th class="border-top-0">#</th>
                                            <th class="border-top-0">Service Name</th>
                                            <th class="border-top-0">Service Price</th>
                                            <th class="border-top-0">Service Image</th>
                                            <th class="border-top-0">Short Description</th>
                                            <th class="border-top-0">Long Description</th>
                                            <th class="border-top-0">Status</th>
                                            <th class="border-top-0">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($service->service_name); ?></td>
                                            <td><?php echo e($service->service_price); ?></td>
                                            <td><img src="/uploads/services/<?php echo e($service->service_image); ?>" alt="" width="100px"></td>
                                            <td><?php echo e($service->short_desc); ?></td>
                                            <td><?php echo $service->long_desc; ?></td>
                                            <td>
                                                <?php if($service->service_status == 1): ?>
                                                Active
                                                <a href="<?php echo e(url('service-deactive/'.$service->id)); ?>" class="btn btn-warning btn-sm" data-bs-toggle="tooltip" data-bs-placement="top" title="Deactive The Service">
                                                    <i class="fa fa-times" aria-hidden="true"></i>
                                                </a>
                                                <?php elseif($service->service_status == 0): ?>
                                                Deactive
                                                <a href="<?php echo e(url('service-active/'.$service->id)); ?>" class="btn btn-success btn-sm" data-bs-toggle="tooltip" data-bs-placement="top" title="Active The Service">
                                                    <i class="fa fa-check" aria-hidden="true"></i>
                                                </a>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(url('/edit-service/'.$service->id)); ?>"
                                                class="btn btn-info text-white">Edit
                                                </a>
                                                <a href="<?php echo e(url('/delete-service/'.$service->id)); ?>"
                                                class="btn btn-danger text-white deleteBtn">Delete
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            
<?php $__env->stopSection(); ?>
        
        
 
        

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\github\set_app\resources\views/admin/services/index.blade.php ENDPATH**/ ?>