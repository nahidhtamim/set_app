
 <?php $__env->startSection('title'); ?>
 Clothes - SET Admin Panel
 <?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>
            
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb bg-white">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Clothes
                            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#locationModal">
                                Services Cycle Locations
                            </button>
                        </h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <div class="d-md-flex">
                            <ol class="breadcrumb ms-auto">
                                <li><a href="<?php echo e(url('/clothes')); ?>" class="fw-normal">Clothes</a></li>
                            </ol>
                            <a href="<?php echo e(url('/add-cloth')); ?>"
                                class="btn btn-success pull-right ms-3 hidden-xs hidden-sm waves-effect waves-light text-white">Add Cloth
                                </a>
                        </div>
                    </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Three charts -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box">
                            <h3 class="box-title">Clothes Table</h3>

                            <?php if(session('status')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php elseif(session('warning')): ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo e(session('warning')); ?>

                            </div>
                            <?php endif; ?>

                            <div class="table-responsive">
                                <table class="table text-nowrap table-bordered table-striped" id="table">
                                    <thead>
                                        <tr>
                                            <th class="border-top-0">#</th>
                                            <th class="border-top-0">RFID Code</th>
                                            <th class="border-top-0">Customer</th>
                                            <th class="border-top-0">Order Info</th>
                                            <th class="border-top-0">Service & Cloting Set</th>
                                            <th class="border-top-0">Service Cycle Status</th>
                                            <th class="border-top-0">Cloth Status</th>
                                            <th class="border-top-0">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $clothes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cloth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($cloth->hexa_code); ?></td>
                                            <td>
                                                <b>Name:</b> <?php echo e($cloth->customer_inf->name); ?>

                                                <br>
                                                <b>DoB:</b> <?php echo e($cloth->customer_inf->dob); ?>

                                                <br>
                                                <b>Gender:</b> <?php echo e($cloth->customer_inf->gender); ?>

                                            </td>
                                            <td> 
                                                <b>Order No:</b> <?php echo e($cloth->order_id); ?> <br>
                                                <b>Storage:</b> 
                                                    <?php $__currentLoopData = $lockers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($locker->id == $cloth->order_inf->locker_id): ?>
                                                            <?php echo e($locker->storage_name); ?> 
                                                        <?php endif; ?>
                                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <br>
                                                <b>Place:</b> 
                                                    <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($place->id == $cloth->order_inf->place_id): ?>
                                                            <?php echo e($place->place_name); ?> 
                                                        <?php endif; ?>
                                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <br>
                                                <b>Locker:</b> 
                                                    <?php $__currentLoopData = $lockers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($locker->id == $cloth->order_inf->locker_id): ?>
                                                            <?php echo e($locker->name); ?> 
                                                        <?php endif; ?>
                                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td>
                                                <b>Service Name:</b> <?php echo e($cloth->service_inf->service_name); ?> <br>
                                                <b>Clothing Set:</b> <?php echo e($cloth->set_id); ?> <br>
                                            </td>
                                            <td class="text-center">
                                                <?php if($cloth->wash_program_number == '0'): ?>
                                                New Entry
                                                <?php else: ?>
                                                <?php echo e($cloth->service_cycle_location_inf->location); ?>

                                                <?php endif; ?>
                                                <br>
                                                <form method="POST" action="<?php echo e(url('update-service-location-status/'.$cloth->id)); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="input-group mb-3">
                                                        <select class="form-select" name="wash_program_number" id="inputGroupSelect02">
                                                          <option selected>Update Status</option>
                                                            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($location->id); ?>"><?php echo e($location->location); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        <button class="btn btn-outline-success" type="submit">Update</button>
                                                    </div>
                                                </form>
                                                
                                            </td>
                                            <td>
                                                <a href="<?php echo e(url('load-laundries/'.$cloth->set_id.'/'.$cloth->order_id.'/'.$cloth->customer_id)); ?>"
                                                    class="btn btn-secondary text-white">View Cloths
                                                </a>
                                            </td>
                                            <td>
                                                
                                                <a href="<?php echo e(url('/edit-cloth/'.$cloth->id)); ?>"
                                                class="btn btn-info text-white">Edit
                                                </a>
                                                <a href="<?php echo e(url('/delete-cloth/'.$cloth->id)); ?>"
                                                class="btn btn-danger text-white" onclick="return confirm('Are you sure to delete?')">Delete
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->

              <!-- Modal -->
              <div class="modal fade" id="locationModal" tabindex="-1" aria-labelledby="locationModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                    <h5 class="modal-title" id="locationModalLabel">Services Cycle Locations</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <table class="table text-nowrap table-bordered table-striped" id="table">
                            <thead>
                                <tr>
                                    <th class="border-top-0">Serial</th>
                                    <th class="border-top-0">Locations</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($location->location); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
                </div>
            </div>

<?php $__env->stopSection(); ?>
        
        
    
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\set_app\resources\views/admin/clothes/index.blade.php ENDPATH**/ ?>