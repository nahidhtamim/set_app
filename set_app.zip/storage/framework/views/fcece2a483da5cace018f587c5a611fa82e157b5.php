
 <?php $__env->startSection('title'); ?>
 Clothes - SET Admin Panel
 <?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>
            
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb bg-white">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Clothes</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <div class="d-md-flex">
                            <ol class="breadcrumb ms-auto">
                                <li><a href="<?php echo e(url('/clothes')); ?>" class="fw-normal">Clothes</a></li>
                            </ol>
                            <a href="<?php echo e(url('/add-cloth')); ?>"
                                class="btn btn-success  d-none d-md-block pull-right ms-3 hidden-xs hidden-sm waves-effect waves-light text-white">Add Cloth
                                </a>
                        </div>
                    </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Three charts -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box">
                            <h3 class="box-title">Clothes Table</h3>

                            <?php if(session('status')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php elseif(session('warning')): ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo e(session('warning')); ?>

                            </div>
                            <?php endif; ?>

                            <div class="table-responsive">
                                <table class="table text-nowrap table-bordered table-striped" id="table">
                                    <thead>
                                        <tr>
                                            <th class="border-top-0">#</th>
                                            <th class="border-top-0">Hexa Code</th>
                                            <th class="border-top-0">Customer</th>
                                            <th class="border-top-0">Order No</th>
                                            <th class="border-top-0">Service & Cloting Set</th>
                                            <th class="border-top-0">Details</th>
                                            <th class="border-top-0">Image</th>
                                            <th class="border-top-0">Wash Status</th>
                                            <th class="border-top-0">Dryer Status</th>
                                            <th class="border-top-0">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $clothes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cloth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($cloth->hexa_code); ?></td>
                                            <td><?php echo e($cloth->customer_inf->name); ?></td>
                                            <td><?php echo e($cloth->order_id); ?></td>
                                            <td>
                                                <b>Service Name:</b> <?php echo e($cloth->service_inf->service_name); ?> <br>
                                                <b>Clothing Set:</b> <?php echo e($cloth->set_id); ?> <br>
                                            </td>
                                            <td>
                                                <b>Cloth Type:</b> <?php echo e($cloth->cloth_type); ?> <br>
                                                <b>Size:</b> <?php echo e($cloth->size); ?> <br>
                                                <b>Color:</b> <?php echo e($cloth->color); ?> <br>
                                                <b>Fabric:</b> <?php echo e($cloth->fabric); ?> <br>
                                                <b>Weight:</b> <?php echo e($cloth->weight); ?> <br>
                                                <b>Brand:</b> <?php echo e($cloth->brand); ?> <br>
                                            </td>
                                            <td><img src="/uploads/clothes/<?php echo e($cloth->image); ?>" alt="" width="100px"></td>
                                            <td>
                                                <?php echo e($cloth->wash_program_number); ?>

                                            </td>
                                            <td>
                                                <?php echo e($cloth->dryer_program_number); ?>

                                            </td>
                                            <td>
                                                <a href="<?php echo e(url('/edit-cloth/'.$cloth->id)); ?>"
                                                class="btn btn-info text-white">Edit
                                                </a>
                                                <a href="<?php echo e(url('/delete-cloth/'.$cloth->id)); ?>"
                                                class="btn btn-danger text-white" onclick="return confirm('Are you sure to delete?')">Delete
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            
<?php $__env->stopSection(); ?>
        
        
 
        

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\set_app\resources\views/admin/clothes/index.blade.php ENDPATH**/ ?>