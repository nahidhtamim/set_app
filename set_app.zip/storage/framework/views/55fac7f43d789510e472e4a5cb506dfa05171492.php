<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
      <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('frontend/assets/images/logo.png')); ?>" alt="" height="50px"></a>
      <button class="navbar-toggler text-light" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain" aria-controls="navbarMain" aria-expanded="false" aria-label="Toggle navigation">
        Menu
      </button>        
      <div class="collapse navbar-collapse" id="navbarMain">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="<?php echo e(url('/')); ?>">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('/about')); ?>">About</a>
          </li>
          <?php if(isset(Auth::user()->name)): ?> 
          <li class="nav-item">
            <a class="nav-link" href="#">
              <input type="checkbox" data-id="<?php echo e(Auth::user()->id); ?>" name="online_status" class="js-switch" <?php echo e(Auth::user()->online_status == 1 ? 'checked' : ''); ?>>
            </a>
          </li>
          
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <i class="fa fa-user"></i>
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
              <li><a class="dropdown-item" href="<?php echo e(url('/my-profile')); ?>">Profile</a></li>
              <li><a class="dropdown-item" href="<?php echo e(url('/my-orders')); ?>">Order</a></li>
              <li><hr class="dropdown-divider"></li>
              <li>
                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                   onclick="event.preventDefault();
                                 document.getElementById('logout-form').submit();">
                    <?php echo e(__('Logout')); ?>

                </a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </li>
            </ul>
          </li>
          <?php else: ?>
          
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <i class="fa fa-user"></i>
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
              <li><a class="dropdown-item" href="<?php echo e(route('login')); ?>">Login</a></li>
              <li><a class="dropdown-item" href="<?php echo e(route('register')); ?>">Register</a></li>
            </ul>
          </li>
          <?php endif; ?>
        </ul>
      </div><!--/.nav-collapse -->
    </div>
  </nav><?php /**PATH C:\xampp\htdocs\set_app\resources\views/layouts/frontend_includes/navbar.blade.php ENDPATH**/ ?>