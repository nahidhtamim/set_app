
            
                <div class="modal-dialog modal-lg">
                    <div class="modal-content laundryItemsList">
                        <div class="modal-header">
                        <h5 class="modal-title" id="laundryItemsModalLabel">Washing Programs</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="table-responsive">
                                <table class="table text-nowrap table-bordered table-striped" id="table">
                                    <thead>
                                        <tr>
                                            <th class="border-top-0">#</th>
                                            <th class="border-top-0">Customer</th>
                                            <th class="border-top-0">Clothing Set</th>
                                            <th class="border-top-0">Washing Program</th>
                                            <th class="border-top-0">Color Group</th>
                                            <th class="border-top-0">Cloth Type</th>
                                            <th class="border-top-0">Fabric</th>
                                            <th class="border-top-0">Sportswear Type</th>
                                            <th class="border-top-0">Description</th>
                                            <th class="border-top-0">Status</th>
                                            <th class="border-top-0">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $laundries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laundry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($laundry->user_inf->name); ?></td>
                                                <td><?php echo e($laundry->set_id); ?></td>
                                                <td><?php echo e($laundry->washing_program_inf->name); ?></td>
                                                <td><?php echo e($laundry->cloth_group_inf->name); ?></td>
                                                <td><?php echo e($laundry->cloth_type_inf->name); ?></td>
                                                <td><?php echo e($laundry->fabric_inf->name); ?></td>
                                                <td><?php echo e($laundry->sportswear_inf->name); ?></td>
                                                <td><?php echo $laundry->laundry_description; ?></td>
                                                <td>
                                                    <?php if($laundry->status == 1): ?>
                                                    Active
                                                    <a href="<?php echo e(url('laundry-deactive/'.$laundry->id)); ?>" class="btn btn-warning btn-sm" data-bs-toggle="tooltip" data-bs-placement="top" title="Deactive The Laundry">
                                                        <i class="fa fa-times" aria-hidden="true"></i>
                                                    </a>
                                                    <?php elseif($laundry->status == 0): ?>
                                                    Deactive
                                                    <a href="<?php echo e(url('laundry-active/'.$laundry->id)); ?>" class="btn btn-success btn-sm" data-bs-toggle="tooltip" data-bs-placement="top" title="Active The Laundry">
                                                        <i class="fa fa-check" aria-hidden="true"></i>
                                                    </a>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(url('/edit-laundry/'.$laundry->id)); ?>"
                                                    class="btn btn-info text-white">Edit
                                                    </a>
                                                    <a href="<?php echo e(url('/delete-laundry/'.$laundry->id)); ?>"
                                                    class="btn btn-danger text-white" onclick="return confirm('Are you sure to delete?')">Delete
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            <?php /**PATH C:\xampp\htdocs\set_app\resources\views/admin/clothes/laundryItemModal.blade.php ENDPATH**/ ?>